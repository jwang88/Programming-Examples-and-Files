package com.example.myownfrag

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val frag1 = Fragment1()

        val manager = fragmentManager

        val frag_transaction = manager.beginTransaction()

        frag_transaction.add(R.id.frag_container,frag1)
        frag_transaction.commit()
    }
}
