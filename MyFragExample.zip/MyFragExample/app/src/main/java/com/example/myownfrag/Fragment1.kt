package com.example.myownfrag


import android.os.Bundle
import android.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

/**
 * A simple [Fragment] subclass.
 */
class Fragment1 : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val returning =  inflater.inflate(R.layout.fragment_fragment1, container, false)

        val firstButton = returning.findViewById<Button>(R.id.FragButton1)

        firstButton.setOnClickListener() {
            val frag2 = Fragment2()

            val manager = fragmentManager

            val frag_transaction = manager.beginTransaction()

            frag_transaction.replace(R.id.frag_container, frag2)
            frag_transaction.commit()
        }

        return returning
    }


}
